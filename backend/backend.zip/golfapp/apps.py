from django.apps import AppConfig


class GolfappConfig(AppConfig):
    name = 'golfapp'
